"use strict";
/**
 * Common Business BaseClass
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=BaseBusiness.js.map