"use strict";
/**
 * Interface for Employee Business Logic */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IEmployeeBusiness.js.map