"use strict";
/**
 * interface for User model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IContactformModel.js.map