"use strict";
/**
 * interface for Emplooye model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IEmployeeModel.js.map