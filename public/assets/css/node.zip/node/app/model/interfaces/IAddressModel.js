"use strict";
/**
 * interface for Company model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IAddressModel.js.map